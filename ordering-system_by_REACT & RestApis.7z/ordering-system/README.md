# Ordering System

A complete ordering system built with React frontend and FastAPI backend, deployable on Vercel. This system allows users to browse items, place orders with automatic discount application, and provides staff management capabilities for inventory and offers.

## Features

### Customer Features
- **Browse Items**: View available items with prices and stock levels
- **Shopping Cart**: Add items to cart with quantity management
- **Order Placement**: Place orders with automatic discount calculation
- **Offers Viewing**: See available discounts and promotions

### Staff Features
- **Inventory Management**: Add, update, and remove items
- **Offer Management**: Create and manage discount offers
- **Real-time Updates**: Changes reflect immediately across the system

### Technical Features
- **Thread-safe Storage**: In-memory storage with proper synchronization
- **Input Validation**: Comprehensive validation on both frontend and backend
- **Error Handling**: Meaningful error messages and proper HTTP status codes
- **Observability**: Logging for all API operations
- **Responsive Design**: Mobile-friendly interface

## Technology Stack

### Frontend
- **React 18** with TypeScript
- **Next.js 14** (App Router)
- **Vanilla CSS** with CSS Modules
- **Functional Components** with React Hooks

### Backend
- **FastAPI** with Python 3.9+
- **Pydantic** for data validation
- **Uvicorn** ASGI server
- **Threading** for thread-safe operations

### Deployment
- **Vercel** for hosting
- **Serverless Functions** for API endpoints

## Project Structure

\`\`\`
ordering-system/
├── api/                    # FastAPI backend
│   ├── main.py            # Main API application
│   └── requirements.txt   # Python dependencies
├── app/                   # Next.js frontend
│   ├── page.tsx          # Main application page
│   ├── page.module.css   # Main page styles
│   └── globals.css       # Global styles
├── components/            # React components
│   ├── item-browser.tsx  # Item browsing component
│   ├── cart.tsx          # Shopping cart component
│   ├── offers-list.tsx   # Offers display component
│   ├── staff-panel.tsx   # Staff management panel
│   └── \*.module.css      # Component-specific styles
├── vercel.json           # Vercel deployment configuration
├── package.json          # Node.js dependencies
└── README.md             # This file
\`\`\`

## API Endpoints

### Public Endpoints

#### GET /api/items
Returns all available items with stock information.

**Response:**
\`\`\`json
{
  "items": [
    {
      "id": "1",
      "name": "Coffee",
      "price": 4.99,
      "stock": 50
    }
  ]
}
\`\`\`

#### POST /api/orders
Creates a new order with automatic discount application.

**Request:**
\`\`\`json
{
  "items": [
    {
      "item_id": "1",
      "quantity": 3
    }
  ]
}
\`\`\`

**Response:**
\`\`\`json
{
  "order": {
    "id": "uuid",
    "items": [...],
    "subtotal": 14.97,
    "discount_percentage": 10,
    "discount_amount": 1.50,
    "total": 13.47,
    "created_at": "2024-01-01T12:00:00"
  }
}
\`\`\`

#### GET /api/offers
Returns all available offers and discounts.

**Response:**
\`\`\`json
{
  "offers": [
    {
      "id": "1",
      "name": "Bulk Coffee Discount",
      "description": "10% off when buying 3+ coffees",
      "discount_percentage": 10,
      "min_quantity": 3,
      "applicable_items": ["1"]
    }
  ]
}
\`\`\`

### Staff Management Endpoints

#### POST /api/items-management
Add or update items in inventory.

**Request:**
\`\`\`json
{
  "name": "New Item",
  "price": 9.99,
  "stock": 25
}
\`\`\`

#### DELETE /api/items-management/{item_id}
Remove an item from inventory.

#### POST /api/offers-management
Add or update offers.

**Request:**
\`\`\`json
{
  "name": "New Offer",
  "description": "Description of the offer",
  "discount_percentage": 15,
  "min_quantity": 2,
  "applicable_items": []
}
\`\`\`

#### DELETE /api/offers-management/{offer_id}
Remove an offer.

## Setup Instructions

### Prerequisites
- Node.js 18+ and npm
- Python 3.9+
- Git

### Local Development

1. **Clone the repository:**
   \`\`\`bash
   git clone <repository-url>
   cd ordering-system
   \`\`\`

2. **Install frontend dependencies:**
   \`\`\`bash
   npm install
   \`\`\`

3. **Install backend dependencies:**
   \`\`\`bash
   cd api
   pip install -r requirements.txt
   cd ..
   \`\`\`

4. **Run the development server:**
   \`\`\`bash
   npm run dev
   \`\`\`

5. **Run the FastAPI backend separately (optional for local testing):**
   \`\`\`bash
   cd api
   uvicorn main:app --reload --port 8000
   \`\`\`

The application will be available at \`http://localhost:3000\`.

### Vercel Deployment

1. **Push to GitHub:**
   \`\`\`bash
   git add .
   git commit -m "Initial commit"
   git push origin main
   \`\`\`

2. **Deploy to Vercel:**
   - Connect your GitHub repository to Vercel
   - Vercel will automatically detect the configuration from \`vercel.json\`
   - The deployment will handle both frontend and backend automatically

3. **Environment Variables (if needed):**
   - No environment variables are required for basic functionality
   - All configuration is handled through the codebase

## Design Decisions

### Frontend Architecture
- **React with TypeScript**: Provides type safety and better development experience
- **Vanilla CSS with CSS Modules**: Offers full control over styling without framework dependencies
- **Component-based Architecture**: Modular, reusable components following React best practices
- **State Management**: Uses React hooks for local state management, suitable for the application scope

### Backend Architecture
- **FastAPI**: Modern, fast Python framework with automatic API documentation
- **Pydantic Models**: Ensures data validation and type safety
- **In-memory Storage**: Simple storage solution with thread-safe operations
- **RESTful Design**: Clear, predictable API endpoints following REST conventions

### Styling Approach
- **CSS Modules**: Scoped styles prevent conflicts and improve maintainability
- **BEM-like Naming**: Clear, descriptive class names
- **Responsive Design**: Mobile-first approach with flexible layouts
- **Professional UI**: Clean, modern design with consistent spacing and typography

### Validation Strategy
- **Frontend Validation**: Immediate feedback for user inputs
- **Backend Validation**: Comprehensive server-side validation using Pydantic
- **Error Handling**: User-friendly error messages with proper HTTP status codes

## Trade-offs and Limitations

### Storage
- **In-memory Storage**: 
  - ✅ Simple implementation, fast access
  - ❌ Data lost on server restart, not suitable for production scale
  - **Alternative**: Database integration (PostgreSQL, MongoDB) for persistence

### Authentication
- **No Authentication**: 
  - ✅ Simplified development and deployment
  - ❌ No user management or access control
  - **Alternative**: JWT tokens, OAuth integration for production use

### Scalability
- **Single Instance**: 
  - ✅ Simple deployment model
  - ❌ Limited concurrent users, no horizontal scaling
  - **Alternative**: Database with connection pooling, Redis for caching

### State Management
- **Local State Only**: 
  - ✅ Simple state management, no external dependencies
  - ❌ No state persistence across browser sessions
  - **Alternative**: Redux, Zustand, or localStorage for state persistence

### Real-time Updates
- **Manual Refresh**: 
  - ✅ Simple implementation
  - ❌ No real-time inventory updates
  - **Alternative**: WebSocket connections, Server-Sent Events for real-time updates

## Testing

### Manual Testing Checklist

#### Customer Flow
- [ ] Browse items and view details
- [ ] Add items to cart with different quantities
- [ ] Modify cart quantities and remove items
- [ ] Place order and verify discount application
- [ ] View available offers

#### Staff Flow
- [ ] Add new items with validation
- [ ] Update existing items
- [ ] Delete items
- [ ] Create new offers with different conditions
- [ ] Delete offers
- [ ] Verify changes reflect in customer view

#### Error Handling
- [ ] Test invalid inputs (negative prices, empty fields)
- [ ] Test insufficient stock scenarios
- [ ] Test network error handling
- [ ] Test form validation messages

## Future Enhancements

### Short-term
- User authentication and authorization
- Order history and tracking
- Email notifications for orders
- Advanced offer conditions (buy X get Y free)

### Medium-term
- Database integration for data persistence
- Payment processing integration
- Inventory alerts for low stock
- Analytics dashboard for staff

### Long-term
- Multi-tenant support for multiple stores
- Mobile app development
- Advanced reporting and analytics
- Integration with external inventory systems

## Contributing

1. Fork the repository
2. Create a feature branch (\`git checkout -b feature/new-feature\`)
3. Commit your changes (\`git commit -am 'Add new feature'\`)
4. Push to the branch (\`git push origin feature/new-feature\`)
5. Create a Pull Request

## License

This project is licensed under the MIT License - see the LICENSE file for details.
