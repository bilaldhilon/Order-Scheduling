from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, validator
from typing import List, Optional, Dict, Any
import logging
import threading
from datetime import datetime
import uuid

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = FastAPI(title="Ordering System API", version="1.0.0")

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Thread-safe storage with locks
storage_lock = threading.Lock()

# In-memory storage
items_storage: Dict[str, Dict[str, Any]] = {
    "1": {"id": "1", "name": "Coffee", "price": 4.99, "stock": 50},
    "2": {"id": "2", "name": "Sandwich", "price": 8.99, "stock": 30},
    "3": {"id": "3", "name": "Salad", "price": 12.99, "stock": 25},
    "4": {"id": "4", "name": "Pastry", "price": 3.99, "stock": 40},
}

offers_storage: Dict[str, Dict[str, Any]] = {
    "1": {
        "id": "1",
        "name": "Bulk Coffee Discount",
        "description": "10% off when buying 3+ coffees",
        "discount_percentage": 10,
        "min_quantity": 3,
        "applicable_items": ["1"]
    },
    "2": {
        "id": "2",
        "name": "Lunch Combo",
        "description": "15% off when buying 2+ different items",
        "discount_percentage": 15,
        "min_quantity": 2,
        "applicable_items": []
    }
}

orders_storage: Dict[str, Dict[str, Any]] = {}

# Pydantic models
class Item(BaseModel):
    name: str
    price: float
    stock: int

    @validator('price')
    def price_must_be_positive(cls, v):
        if v <= 0:
            raise ValueError('Price must be positive')
        return v

    @validator('stock')
    def stock_must_be_non_negative(cls, v):
        if v < 0:
            raise ValueError('Stock must be non-negative')
        return v

class OrderItem(BaseModel):
    item_id: str
    quantity: int

    @validator('quantity')
    def quantity_must_be_positive(cls, v):
        if v <= 0:
            raise ValueError('Quantity must be positive')
        return v

class Order(BaseModel):
    items: List[OrderItem]

class Offer(BaseModel):
    name: str
    description: str
    discount_percentage: float
    min_quantity: int
    applicable_items: List[str] = []

    @validator('discount_percentage')
    def discount_must_be_valid(cls, v):
        if v < 0 or v > 100:
            raise ValueError('Discount percentage must be between 0 and 100')
        return v

    @validator('min_quantity')
    def min_quantity_must_be_positive(cls, v):
        if v <= 0:
            raise ValueError('Minimum quantity must be positive')
        return v

# Helper functions
def calculate_discount(order_items: List[OrderItem], offers: Dict[str, Dict[str, Any]]) -> float:
    """Calculate total discount for an order"""
    total_discount = 0.0
    
    for offer in offers.values():
        applicable_items = offer.get("applicable_items", [])
        min_quantity = offer.get("min_quantity", 1)
        discount_percentage = offer.get("discount_percentage", 0)
        
        if not applicable_items:  # Apply to all items
            total_quantity = sum(item.quantity for item in order_items)
            if total_quantity >= min_quantity:
                total_discount = max(total_discount, discount_percentage)
        else:  # Apply to specific items
            applicable_quantity = sum(
                item.quantity for item in order_items 
                if item.item_id in applicable_items
            )
            if applicable_quantity >= min_quantity:
                total_discount = max(total_discount, discount_percentage)
    
    return total_discount

# API Endpoints

@app.get("/")
async def root():
    return {"message": "Ordering System API", "status": "running"}

@app.get("/items")
async def get_items():
    """Get all available items"""
    try:
        with storage_lock:
            items = list(items_storage.values())
        logger.info(f"Retrieved {len(items)} items")
        return {"items": items}
    except Exception as e:
        logger.error(f"Error retrieving items: {str(e)}")
        raise HTTPException(status_code=500, detail="Internal server error")

@app.post("/orders")
async def create_order(order: Order):
    """Create a new order"""
    try:
        with storage_lock:
            # Validate items exist and have sufficient stock
            order_total = 0.0
            order_items_details = []
            
            for order_item in order.items:
                if order_item.item_id not in items_storage:
                    raise HTTPException(
                        status_code=404, 
                        detail=f"Item with id {order_item.item_id} not found"
                    )
                
                item = items_storage[order_item.item_id]
                if item["stock"] < order_item.quantity:
                    raise HTTPException(
                        status_code=400,
                        detail=f"Insufficient stock for {item['name']}. Available: {item['stock']}, Requested: {order_item.quantity}"
                    )
                
                item_total = item["price"] * order_item.quantity
                order_total += item_total
                
                order_items_details.append({
                    "item_id": order_item.item_id,
                    "name": item["name"],
                    "price": item["price"],
                    "quantity": order_item.quantity,
                    "subtotal": item_total
                })
                
                # Update stock
                items_storage[order_item.item_id]["stock"] -= order_item.quantity
            
            # Calculate discount
            discount_percentage = calculate_discount(order.items, offers_storage)
            discount_amount = order_total * (discount_percentage / 100)
            final_total = order_total - discount_amount
            
            # Create order
            order_id = str(uuid.uuid4())
            new_order = {
                "id": order_id,
                "items": order_items_details,
                "subtotal": order_total,
                "discount_percentage": discount_percentage,
                "discount_amount": discount_amount,
                "total": final_total,
                "created_at": datetime.now().isoformat()
            }
            
            orders_storage[order_id] = new_order
            
        logger.info(f"Created order {order_id} with total ${final_total:.2f}")
        return {"order": new_order, "message": "Order created successfully"}
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error creating order: {str(e)}")
        raise HTTPException(status_code=500, detail="Internal server error")

@app.get("/offers")
async def get_offers():
    """Get all available offers"""
    try:
        with storage_lock:
            offers = list(offers_storage.values())
        logger.info(f"Retrieved {len(offers)} offers")
        return {"offers": offers}
    except Exception as e:
        logger.error(f"Error retrieving offers: {str(e)}")
        raise HTTPException(status_code=500, detail="Internal server error")

@app.post("/items-management")
async def manage_item(item: Item, item_id: Optional[str] = None):
    """Add or update an item"""
    try:
        with storage_lock:
            if item_id and item_id in items_storage:
                # Update existing item
                items_storage[item_id].update({
                    "name": item.name,
                    "price": item.price,
                    "stock": item.stock
                })
                logger.info(f"Updated item {item_id}")
                return {"message": "Item updated successfully", "item": items_storage[item_id]}
            else:
                # Add new item
                new_id = str(len(items_storage) + 1)
                new_item = {
                    "id": new_id,
                    "name": item.name,
                    "price": item.price,
                    "stock": item.stock
                }
                items_storage[new_id] = new_item
                logger.info(f"Added new item {new_id}")
                return {"message": "Item added successfully", "item": new_item}
                
    except Exception as e:
        logger.error(f"Error managing item: {str(e)}")
        raise HTTPException(status_code=500, detail="Internal server error")

@app.delete("/items-management/{item_id}")
async def delete_item(item_id: str):
    """Delete an item"""
    try:
        with storage_lock:
            if item_id not in items_storage:
                raise HTTPException(status_code=404, detail="Item not found")
            
            deleted_item = items_storage.pop(item_id)
            
        logger.info(f"Deleted item {item_id}")
        return {"message": "Item deleted successfully", "deleted_item": deleted_item}
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error deleting item: {str(e)}")
        raise HTTPException(status_code=500, detail="Internal server error")

@app.post("/offers-management")
async def manage_offer(offer: Offer, offer_id: Optional[str] = None):
    """Add or update an offer"""
    try:
        with storage_lock:
            if offer_id and offer_id in offers_storage:
                # Update existing offer
                offers_storage[offer_id].update({
                    "name": offer.name,
                    "description": offer.description,
                    "discount_percentage": offer.discount_percentage,
                    "min_quantity": offer.min_quantity,
                    "applicable_items": offer.applicable_items
                })
                logger.info(f"Updated offer {offer_id}")
                return {"message": "Offer updated successfully", "offer": offers_storage[offer_id]}
            else:
                # Add new offer
                new_id = str(len(offers_storage) + 1)
                new_offer = {
                    "id": new_id,
                    "name": offer.name,
                    "description": offer.description,
                    "discount_percentage": offer.discount_percentage,
                    "min_quantity": offer.min_quantity,
                    "applicable_items": offer.applicable_items
                }
                offers_storage[new_id] = new_offer
                logger.info(f"Added new offer {new_id}")
                return {"message": "Offer added successfully", "offer": new_offer}
                
    except Exception as e:
        logger.error(f"Error managing offer: {str(e)}")
        raise HTTPException(status_code=500, detail="Internal server error")

@app.delete("/offers-management/{offer_id}")
async def delete_offer(offer_id: str):
    """Delete an offer"""
    try:
        with storage_lock:
            if offer_id not in offers_storage:
                raise HTTPException(status_code=404, detail="Offer not found")
            
            deleted_offer = offers_storage.pop(offer_id)
            
        logger.info(f"Deleted offer {offer_id}")
        return {"message": "Offer deleted successfully", "deleted_offer": deleted_offer}
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error deleting offer: {str(e)}")
        raise HTTPException(status_code=500, detail="Internal server error")

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
