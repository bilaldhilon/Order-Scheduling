"use client"

import { useState } from "react"
import ItemBrowser from "@/components/item-browser"
import Cart from "@/components/cart"
import StaffPanel from "@/components/staff-panel"
import OffersList from "@/components/offers-list"
import styles from "./page.module.css"

export default function Home() {
  const [activeTab, setActiveTab] = useState("browse")
  const [cartItems, setCartItems] = useState<Array<{ id: string; name: string; price: number; quantity: number }>>([])

  const addToCart = (item: { id: string; name: string; price: number }) => {
    setCartItems((prev) => {
      const existing = prev.find((cartItem) => cartItem.id === item.id)
      if (existing) {
        return prev.map((cartItem) =>
          cartItem.id === item.id ? { ...cartItem, quantity: cartItem.quantity + 1 } : cartItem,
        )
      }
      return [...prev, { ...item, quantity: 1 }]
    })
  }

  const updateCartQuantity = (id: string, quantity: number) => {
    if (quantity <= 0) {
      setCartItems((prev) => prev.filter((item) => item.id !== id))
    } else {
      setCartItems((prev) => prev.map((item) => (item.id === id ? { ...item, quantity } : item)))
    }
  }

  const clearCart = () => {
    setCartItems([])
  }

  return (
    <div className={styles.container}>
      <header className={styles.header}>
        <h1>Ordering System</h1>
        <nav className={styles.nav}>
          <button
            className={`${styles.navButton} ${activeTab === "browse" ? styles.active : ""}`}
            onClick={() => setActiveTab("browse")}
          >
            Browse Items
          </button>
          <button
            className={`${styles.navButton} ${activeTab === "cart" ? styles.active : ""}`}
            onClick={() => setActiveTab("cart")}
          >
            Cart ({cartItems.reduce((sum, item) => sum + item.quantity, 0)})
          </button>
          <button
            className={`${styles.navButton} ${activeTab === "offers" ? styles.active : ""}`}
            onClick={() => setActiveTab("offers")}
          >
            Offers
          </button>
          <button
            className={`${styles.navButton} ${activeTab === "staff" ? styles.active : ""}`}
            onClick={() => setActiveTab("staff")}
          >
            Staff Panel
          </button>
        </nav>
      </header>

      <main className={styles.main}>
        {activeTab === "browse" && <ItemBrowser onAddToCart={addToCart} />}
        {activeTab === "cart" && (
          <Cart items={cartItems} onUpdateQuantity={updateCartQuantity} onClearCart={clearCart} />
        )}
        {activeTab === "offers" && <OffersList />}
        {activeTab === "staff" && <StaffPanel />}
      </main>
    </div>
  )
}
