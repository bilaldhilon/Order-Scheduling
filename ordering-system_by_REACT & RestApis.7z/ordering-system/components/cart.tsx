"use client"

import { useState } from "react"
import styles from "./cart.module.css"

interface CartItem {
  id: string
  name: string
  price: number
  quantity: number
}

interface CartProps {
  items: CartItem[]
  onUpdateQuantity: (id: string, quantity: number) => void
  onClearCart: () => void
}

export default function Cart({ items, onUpdateQuantity, onClearCart }: CartProps) {
  const [loading, setLoading] = useState(false)
  const [orderResult, setOrderResult] = useState<any>(null)
  const [error, setError] = useState<string | null>(null)

  const subtotal = items.reduce((sum, item) => sum + item.price * item.quantity, 0)

  const handleQuantityChange = (id: string, newQuantity: string) => {
    const quantity = Number.parseInt(newQuantity)
    if (!isNaN(quantity) && quantity >= 0) {
      onUpdateQuantity(id, quantity)
    }
  }

  const handlePlaceOrder = async () => {
    if (items.length === 0) {
      setError("Cart is empty")
      return
    }

    try {
      setLoading(true)
      setError(null)

      const orderData = {
        items: items.map((item) => ({
          item_id: item.id,
          quantity: item.quantity,
        })),
      }

      const response = await fetch("/api/orders", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(orderData),
      })

      if (!response.ok) {
        const errorData = await response.json()
        throw new Error(errorData.detail || "Failed to place order")
      }

      const result = await response.json()
      setOrderResult(result.order)
      onClearCart()
    } catch (err) {
      setError(err instanceof Error ? err.message : "An error occurred")
    } finally {
      setLoading(false)
    }
  }

  if (orderResult) {
    return (
      <div className={styles.container}>
        <div className={styles.orderSuccess}>
          <h2>Order Placed Successfully!</h2>
          <div className={styles.orderSummary}>
            <h3>Order #{orderResult.id.slice(0, 8)}</h3>
            <div className={styles.orderItems}>
              {orderResult.items.map((item: any, index: number) => (
                <div key={index} className={styles.orderItem}>
                  <span>
                    {item.name} x {item.quantity}
                  </span>
                  <span>${item.subtotal.toFixed(2)}</span>
                </div>
              ))}
            </div>
            <div className={styles.orderTotals}>
              <div className={styles.totalRow}>
                <span>Subtotal:</span>
                <span>${orderResult.subtotal.toFixed(2)}</span>
              </div>
              {orderResult.discount_percentage > 0 && (
                <div className={styles.totalRow}>
                  <span>Discount ({orderResult.discount_percentage}%):</span>
                  <span>-${orderResult.discount_amount.toFixed(2)}</span>
                </div>
              )}
              <div className={`${styles.totalRow} ${styles.finalTotal}`}>
                <span>Total:</span>
                <span>${orderResult.total.toFixed(2)}</span>
              </div>
            </div>
          </div>
          <button onClick={() => setOrderResult(null)} className={styles.newOrderButton}>
            Place New Order
          </button>
        </div>
      </div>
    )
  }

  return (
    <div className={styles.container}>
      <h2>Shopping Cart</h2>

      {error && <div className={styles.error}>{error}</div>}

      {items.length === 0 ? (
        <div className={styles.emptyCart}>
          <p>Your cart is empty</p>
        </div>
      ) : (
        <>
          <div className={styles.cartItems}>
            {items.map((item) => (
              <div key={item.id} className={styles.cartItem}>
                <div className={styles.itemInfo}>
                  <h3>{item.name}</h3>
                  <p className={styles.price}>${item.price.toFixed(2)} each</p>
                </div>
                <div className={styles.quantityControls}>
                  <label htmlFor={`quantity-${item.id}`}>Quantity:</label>
                  <input
                    id={`quantity-${item.id}`}
                    type="number"
                    min="0"
                    value={item.quantity}
                    onChange={(e) => handleQuantityChange(item.id, e.target.value)}
                    className={styles.quantityInput}
                  />
                  <button onClick={() => onUpdateQuantity(item.id, 0)} className={styles.removeButton}>
                    Remove
                  </button>
                </div>
                <div className={styles.itemTotal}>${(item.price * item.quantity).toFixed(2)}</div>
              </div>
            ))}
          </div>

          <div className={styles.cartSummary}>
            <div className={styles.subtotal}>
              <strong>Subtotal: ${subtotal.toFixed(2)}</strong>
            </div>
            <div className={styles.cartActions}>
              <button onClick={onClearCart} className={styles.clearButton} disabled={loading}>
                Clear Cart
              </button>
              <button
                onClick={handlePlaceOrder}
                className={styles.orderButton}
                disabled={loading || items.length === 0}
              >
                {loading ? "Placing Order..." : "Place Order"}
              </button>
            </div>
          </div>
        </>
      )}
    </div>
  )
}
