"use client"

import { useState, useEffect } from "react"
import styles from "./item-browser.module.css"

interface Item {
  id: string
  name: string
  price: number
  stock: number
}

interface ItemBrowserProps {
  onAddToCart: (item: { id: string; name: string; price: number }) => void
}

export default function ItemBrowser({ onAddToCart }: ItemBrowserProps) {
  const [items, setItems] = useState<Item[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    fetchItems()
  }, [])

  const fetchItems = async () => {
    try {
      setLoading(true)
      const response = await fetch("/api/items")
      if (!response.ok) {
        throw new Error("Failed to fetch items")
      }
      const data = await response.json()
      setItems(data.items)
      setError(null)
    } catch (err) {
      setError(err instanceof Error ? err.message : "An error occurred")
    } finally {
      setLoading(false)
    }
  }

  const handleAddToCart = (item: Item) => {
    if (item.stock > 0) {
      onAddToCart({
        id: item.id,
        name: item.name,
        price: item.price,
      })
    }
  }

  if (loading) {
    return <div className={styles.loading}>Loading items...</div>
  }

  if (error) {
    return (
      <div className={styles.error}>
        <p>Error: {error}</p>
        <button onClick={fetchItems} className={styles.retryButton}>
          Retry
        </button>
      </div>
    )
  }

  return (
    <div className={styles.container}>
      <h2>Available Items</h2>
      <div className={styles.itemGrid}>
        {items.map((item) => (
          <div key={item.id} className={styles.itemCard}>
            <div className={styles.itemInfo}>
              <h3>{item.name}</h3>
              <p className={styles.price}>${item.price.toFixed(2)}</p>
              <p className={styles.stock}>
                Stock: {item.stock}
                {item.stock === 0 && <span className={styles.outOfStock}> (Out of Stock)</span>}
              </p>
            </div>
            <button
              onClick={() => handleAddToCart(item)}
              disabled={item.stock === 0}
              className={`${styles.addButton} ${item.stock === 0 ? styles.disabled : ""}`}
            >
              {item.stock === 0 ? "Out of Stock" : "Add to Cart"}
            </button>
          </div>
        ))}
      </div>
    </div>
  )
}
