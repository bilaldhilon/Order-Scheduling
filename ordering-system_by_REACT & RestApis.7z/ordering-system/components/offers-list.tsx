"use client"

import { useState, useEffect } from "react"
import styles from "./offers-list.module.css"

interface Offer {
  id: string
  name: string
  description: string
  discount_percentage: number
  min_quantity: number
  applicable_items: string[]
}

export default function OffersList() {
  const [offers, setOffers] = useState<Offer[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    fetchOffers()
  }, [])

  const fetchOffers = async () => {
    try {
      setLoading(true)
      const response = await fetch("/api/offers")
      if (!response.ok) {
        throw new Error("Failed to fetch offers")
      }
      const data = await response.json()
      setOffers(data.offers)
      setError(null)
    } catch (err) {
      setError(err instanceof Error ? err.message : "An error occurred")
    } finally {
      setLoading(false)
    }
  }

  if (loading) {
    return <div className={styles.loading}>Loading offers...</div>
  }

  if (error) {
    return (
      <div className={styles.error}>
        <p>Error: {error}</p>
        <button onClick={fetchOffers} className={styles.retryButton}>
          Retry
        </button>
      </div>
    )
  }

  return (
    <div className={styles.container}>
      <h2>Available Offers</h2>
      {offers.length === 0 ? (
        <div className={styles.noOffers}>
          <p>No offers available at the moment.</p>
        </div>
      ) : (
        <div className={styles.offersGrid}>
          {offers.map((offer) => (
            <div key={offer.id} className={styles.offerCard}>
              <div className={styles.offerHeader}>
                <h3>{offer.name}</h3>
                <div className={styles.discount}>{offer.discount_percentage}% OFF</div>
              </div>
              <p className={styles.description}>{offer.description}</p>
              <div className={styles.conditions}>
                <p>
                  <strong>Minimum Quantity:</strong> {offer.min_quantity}
                </p>
                {offer.applicable_items.length > 0 && (
                  <p>
                    <strong>Applies to:</strong> Specific items only
                  </p>
                )}
                {offer.applicable_items.length === 0 && (
                  <p>
                    <strong>Applies to:</strong> All items
                  </p>
                )}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}
