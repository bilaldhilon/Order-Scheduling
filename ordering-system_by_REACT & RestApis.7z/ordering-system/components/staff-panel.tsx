"use client"

import type React from "react"

import { useState, useEffect } from "react"
import styles from "./staff-panel.module.css"

interface Item {
  id: string
  name: string
  price: number
  stock: number
}

interface Offer {
  id: string
  name: string
  description: string
  discount_percentage: number
  min_quantity: number
  applicable_items: string[]
}

export default function StaffPanel() {
  const [activeTab, setActiveTab] = useState("items")
  const [items, setItems] = useState<Item[]>([])
  const [offers, setOffers] = useState<Offer[]>([])
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [success, setSuccess] = useState<string | null>(null)

  // Item form state
  const [itemForm, setItemForm] = useState({
    name: "",
    price: "",
    stock: "",
  })

  // Offer form state
  const [offerForm, setOfferForm] = useState({
    name: "",
    description: "",
    discount_percentage: "",
    min_quantity: "",
    applicable_items: "",
  })

  useEffect(() => {
    fetchItems()
    fetchOffers()
  }, [])

  const fetchItems = async () => {
    try {
      const response = await fetch("/api/items")
      if (response.ok) {
        const data = await response.json()
        setItems(data.items)
      }
    } catch (err) {
      console.error("Failed to fetch items:", err)
    }
  }

  const fetchOffers = async () => {
    try {
      const response = await fetch("/api/offers")
      if (response.ok) {
        const data = await response.json()
        setOffers(data.offers)
      }
    } catch (err) {
      console.error("Failed to fetch offers:", err)
    }
  }

  const validateItemForm = () => {
    if (!itemForm.name.trim()) {
      setError("Item name is required")
      return false
    }
    const price = Number.parseFloat(itemForm.price)
    if (isNaN(price) || price <= 0) {
      setError("Price must be a positive number")
      return false
    }
    const stock = Number.parseInt(itemForm.stock)
    if (isNaN(stock) || stock < 0) {
      setError("Stock must be a non-negative number")
      return false
    }
    return true
  }

  const validateOfferForm = () => {
    if (!offerForm.name.trim()) {
      setError("Offer name is required")
      return false
    }
    if (!offerForm.description.trim()) {
      setError("Offer description is required")
      return false
    }
    const discount = Number.parseFloat(offerForm.discount_percentage)
    if (isNaN(discount) || discount < 0 || discount > 100) {
      setError("Discount percentage must be between 0 and 100")
      return false
    }
    const minQty = Number.parseInt(offerForm.min_quantity)
    if (isNaN(minQty) || minQty <= 0) {
      setError("Minimum quantity must be a positive number")
      return false
    }
    return true
  }

  const handleAddItem = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!validateItemForm()) return

    try {
      setLoading(true)
      setError(null)

      const response = await fetch("/api/items-management", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          name: itemForm.name,
          price: Number.parseFloat(itemForm.price),
          stock: Number.parseInt(itemForm.stock),
        }),
      })

      if (!response.ok) {
        const errorData = await response.json()
        throw new Error(errorData.detail || "Failed to add item")
      }

      setSuccess("Item added successfully")
      setItemForm({ name: "", price: "", stock: "" })
      fetchItems()
    } catch (err) {
      setError(err instanceof Error ? err.message : "An error occurred")
    } finally {
      setLoading(false)
    }
  }

  const handleDeleteItem = async (itemId: string) => {
    if (!confirm("Are you sure you want to delete this item?")) return

    try {
      setLoading(true)
      setError(null)

      const response = await fetch(`/api/items-management/${itemId}`, {
        method: "DELETE",
      })

      if (!response.ok) {
        const errorData = await response.json()
        throw new Error(errorData.detail || "Failed to delete item")
      }

      setSuccess("Item deleted successfully")
      fetchItems()
    } catch (err) {
      setError(err instanceof Error ? err.message : "An error occurred")
    } finally {
      setLoading(false)
    }
  }

  const handleAddOffer = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!validateOfferForm()) return

    try {
      setLoading(true)
      setError(null)

      const applicableItems = offerForm.applicable_items
        .split(",")
        .map((id) => id.trim())
        .filter((id) => id)

      const response = await fetch("/api/offers-management", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          name: offerForm.name,
          description: offerForm.description,
          discount_percentage: Number.parseFloat(offerForm.discount_percentage),
          min_quantity: Number.parseInt(offerForm.min_quantity),
          applicable_items: applicableItems,
        }),
      })

      if (!response.ok) {
        const errorData = await response.json()
        throw new Error(errorData.detail || "Failed to add offer")
      }

      setSuccess("Offer added successfully")
      setOfferForm({
        name: "",
        description: "",
        discount_percentage: "",
        min_quantity: "",
        applicable_items: "",
      })
      fetchOffers()
    } catch (err) {
      setError(err instanceof Error ? err.message : "An error occurred")
    } finally {
      setLoading(false)
    }
  }

  const handleDeleteOffer = async (offerId: string) => {
    if (!confirm("Are you sure you want to delete this offer?")) return

    try {
      setLoading(true)
      setError(null)

      const response = await fetch(`/api/offers-management/${offerId}`, {
        method: "DELETE",
      })

      if (!response.ok) {
        const errorData = await response.json()
        throw new Error(errorData.detail || "Failed to delete offer")
      }

      setSuccess("Offer deleted successfully")
      fetchOffers()
    } catch (err) {
      setError(err instanceof Error ? err.message : "An error occurred")
    } finally {
      setLoading(false)
    }
  }

  // Clear messages after 3 seconds
  useEffect(() => {
    if (error || success) {
      const timer = setTimeout(() => {
        setError(null)
        setSuccess(null)
      }, 3000)
      return () => clearTimeout(timer)
    }
  }, [error, success])

  return (
    <div className={styles.container}>
      <h2>Staff Management Panel</h2>

      {error && <div className={styles.error}>{error}</div>}
      {success && <div className={styles.success}>{success}</div>}

      <div className={styles.tabs}>
        <button
          className={`${styles.tab} ${activeTab === "items" ? styles.active : ""}`}
          onClick={() => setActiveTab("items")}
        >
          Manage Items
        </button>
        <button
          className={`${styles.tab} ${activeTab === "offers" ? styles.active : ""}`}
          onClick={() => setActiveTab("offers")}
        >
          Manage Offers
        </button>
      </div>

      {activeTab === "items" && (
        <div className={styles.tabContent}>
          <div className={styles.section}>
            <h3>Add New Item</h3>
            <form onSubmit={handleAddItem} className={styles.form}>
              <div className={styles.formGroup}>
                <label htmlFor="itemName">Item Name:</label>
                <input
                  id="itemName"
                  type="text"
                  value={itemForm.name}
                  onChange={(e) => setItemForm({ ...itemForm, name: e.target.value })}
                  required
                  className={styles.input}
                />
              </div>
              <div className={styles.formGroup}>
                <label htmlFor="itemPrice">Price ($):</label>
                <input
                  id="itemPrice"
                  type="number"
                  step="0.01"
                  min="0.01"
                  value={itemForm.price}
                  onChange={(e) => setItemForm({ ...itemForm, price: e.target.value })}
                  required
                  className={styles.input}
                />
              </div>
              <div className={styles.formGroup}>
                <label htmlFor="itemStock">Stock:</label>
                <input
                  id="itemStock"
                  type="number"
                  min="0"
                  value={itemForm.stock}
                  onChange={(e) => setItemForm({ ...itemForm, stock: e.target.value })}
                  required
                  className={styles.input}
                />
              </div>
              <button type="submit" disabled={loading} className={styles.submitButton}>
                {loading ? "Adding..." : "Add Item"}
              </button>
            </form>
          </div>

          <div className={styles.section}>
            <h3>Current Items</h3>
            <div className={styles.itemsList}>
              {items.map((item) => (
                <div key={item.id} className={styles.itemCard}>
                  <div className={styles.itemInfo}>
                    <h4>{item.name}</h4>
                    <p>Price: ${item.price.toFixed(2)}</p>
                    <p>Stock: {item.stock}</p>
                  </div>
                  <button onClick={() => handleDeleteItem(item.id)} disabled={loading} className={styles.deleteButton}>
                    Delete
                  </button>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {activeTab === "offers" && (
        <div className={styles.tabContent}>
          <div className={styles.section}>
            <h3>Add New Offer</h3>
            <form onSubmit={handleAddOffer} className={styles.form}>
              <div className={styles.formGroup}>
                <label htmlFor="offerName">Offer Name:</label>
                <input
                  id="offerName"
                  type="text"
                  value={offerForm.name}
                  onChange={(e) => setOfferForm({ ...offerForm, name: e.target.value })}
                  required
                  className={styles.input}
                />
              </div>
              <div className={styles.formGroup}>
                <label htmlFor="offerDescription">Description:</label>
                <textarea
                  id="offerDescription"
                  value={offerForm.description}
                  onChange={(e) => setOfferForm({ ...offerForm, description: e.target.value })}
                  required
                  className={styles.textarea}
                />
              </div>
              <div className={styles.formGroup}>
                <label htmlFor="discountPercentage">Discount Percentage (%):</label>
                <input
                  id="discountPercentage"
                  type="number"
                  min="0"
                  max="100"
                  step="0.1"
                  value={offerForm.discount_percentage}
                  onChange={(e) => setOfferForm({ ...offerForm, discount_percentage: e.target.value })}
                  required
                  className={styles.input}
                />
              </div>
              <div className={styles.formGroup}>
                <label htmlFor="minQuantity">Minimum Quantity:</label>
                <input
                  id="minQuantity"
                  type="number"
                  min="1"
                  value={offerForm.min_quantity}
                  onChange={(e) => setOfferForm({ ...offerForm, min_quantity: e.target.value })}
                  required
                  className={styles.input}
                />
              </div>
              <div className={styles.formGroup}>
                <label htmlFor="applicableItems">
                  Applicable Item IDs (comma-separated, leave empty for all items):
                </label>
                <input
                  id="applicableItems"
                  type="text"
                  value={offerForm.applicable_items}
                  onChange={(e) => setOfferForm({ ...offerForm, applicable_items: e.target.value })}
                  placeholder="e.g., 1,2,3"
                  className={styles.input}
                />
              </div>
              <button type="submit" disabled={loading} className={styles.submitButton}>
                {loading ? "Adding..." : "Add Offer"}
              </button>
            </form>
          </div>

          <div className={styles.section}>
            <h3>Current Offers</h3>
            <div className={styles.offersList}>
              {offers.map((offer) => (
                <div key={offer.id} className={styles.offerCard}>
                  <div className={styles.offerInfo}>
                    <h4>{offer.name}</h4>
                    <p>{offer.description}</p>
                    <p>Discount: {offer.discount_percentage}%</p>
                    <p>Min Quantity: {offer.min_quantity}</p>
                    <p>
                      Applies to:{" "}
                      {offer.applicable_items.length > 0 ? `Items ${offer.applicable_items.join(", ")}` : "All items"}
                    </p>
                  </div>
                  <button
                    onClick={() => handleDeleteOffer(offer.id)}
                    disabled={loading}
                    className={styles.deleteButton}
                  >
                    Delete
                  </button>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
